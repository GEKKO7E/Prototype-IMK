
  # DESIGN PROTOTYPE

  This is a code bundle for DESIGN PROTOTYPE. The original project is available at https://www.figma.com/design/MMmAZTBfGdR7OxM96GKN9B/DESIGN-PROTOTYPE.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  